import React from 'react';
import { Routes, Route, Navigate } from 'react-router-dom';
import { AppProvider } from './context/AppContext';
import { Layout } from './components/Layout';
import { HomePage } from './pages/Home';
import { SettingsPage } from './pages/Settings';
import { SplashScreen } from './components/SplashScreen';

function App() {
  const [loading, setLoading] = React.useState(true);

  return (
    <AppProvider>
      {loading && <SplashScreen onFinish={() => setLoading(false)} />}
      <Layout>
        <Routes>
          <Route path="/" element={<HomePage />} />
          <Route path="/settings" element={<SettingsPage />} />
          <Route path="*" element={<Navigate to="/" replace />} />
        </Routes>
      </Layout>
    </AppProvider>
  );
}

export default App;
