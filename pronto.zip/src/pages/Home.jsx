import React, { useRef, useState } from 'react';
import { ChevronLeft, ChevronRight, Fingerprint, Camera, Trash2, Edit2 } from 'lucide-react';
import { useAppContext } from '../context/AppContext';
import { useDailyRecord } from '../hooks/useDailyRecord';
import { M2T, T2M } from '../services/stats';
import { Card, Fab, Modal } from '../components/UI';

const WEEKDAYS = ['Domingo', 'Segunda-feira', 'Terça-feira', 'Quarta-feira', 'Quinta-feira', 'Sexta-feira', 'Sábado'];

export const HomePage = () => {
    const { activeDateISO, changeDate } = useAppContext();
    const { record, stats, addEntry, deleteEntry, updateEntry, updateNote } = useDailyRecord(activeDateISO);
    const [isDeleteModalOpen, setDeleteModalOpen] = useState(false);
    const [entryToDelete, setEntryToDelete] = useState(null);
    const fileInputRef = useRef(null);

    // Date Display
    const dateObj = new Date(activeDateISO);
    const dateDisplay = dateObj.toLocaleDateString('pt-BR', { day: 'numeric', month: 'long' });
    const weekdayDisplay = WEEKDAYS[dateObj.getDay()];

    const handleQuickStamp = () => {
        const n = new Date();
        const time = `${String(n.getHours()).padStart(2, '0')}:${String(n.getMinutes()).padStart(2, '0')}`;
        const count = record.entries?.length || 0;
        const type = count % 2 === 0 ? `Entrada ${Math.floor(count / 2) + 1}` : `Saída ${Math.floor(count / 2) + 1}`;
        addEntry(time, type);
    };

    const handlePhoto = (e, entryId) => {
        const file = e.target.files[0];
        if (!file) return;

        // Resize Image logic
        const reader = new FileReader();
        reader.onload = (ev) => {
            const img = new Image();
            img.onload = () => {
                const canvas = document.createElement('canvas');
                const MAX = 1000;
                let w = img.width;
                let h = img.height;
                if (w > h) { if (w > MAX) { h *= MAX / w; w = MAX; } }
                else { if (h > MAX) { w *= MAX / h; h = MAX; } }
                canvas.width = w;
                canvas.height = h;
                const ctx = canvas.getContext('2d');
                ctx.drawImage(img, 0, 0, w, h);
                const dataUrl = canvas.toDataURL('image/jpeg', 0.7);
                updateEntry(entryId, 'photo', dataUrl);
            };
            img.src = ev.target.result;
        };
        reader.readAsDataURL(file);
    };

    const confirmDelete = (id) => {
        setEntryToDelete(id);
        setDeleteModalOpen(true);
    };

    const executeDelete = () => {
        if (entryToDelete) deleteEntry(entryToDelete);
        setDeleteModalOpen(false);
        setEntryToDelete(null);
    };

    return (
        <div className="space-y-4">
            {/* Header / Date Nav */}
            <div className="flex items-center justify-between px-2">
                <button onClick={() => changeDate(-1)} className="p-2 rounded-full hover:bg-black/5 active:scale-95 transition-transform"><ChevronLeft /></button>
                <div className="text-center">
                    <p className="text-[10px] font-bold text-[var(--primary)] uppercase tracking-widest">{weekdayDisplay}</p>
                    <p className="text-lg font-normal">{dateDisplay}</p>
                </div>
                <button onClick={() => changeDate(1)} className="p-2 rounded-full hover:bg-black/5 active:scale-95 transition-transform"><ChevronRight /></button>
            </div>

            {/* Prediction Card */}
            {stats.prediction !== null && (
                <Card className="bg-[var(--primary)] text-white relative overflow-hidden shadow-lg border-none">
                    <div className="relative z-10">
                        <p className="text-[10px] font-bold uppercase opacity-70 tracking-tighter">Sugestão de Saída</p>
                        <h2 className="text-6xl font-light tracking-tighter">{M2T(stats.prediction)}</h2>
                    </div>
                    <Fingerprint className="absolute -right-4 -top-4 w-24 h-24 opacity-10" />
                </Card>
            )}

            {/* Stats Grid */}
            <div className="grid grid-cols-2 gap-3">
                <Card>
                    <p className="text-[10px] font-bold opacity-50 uppercase mb-1">Trabalhado</p>
                    <p className="text-2xl font-medium">{M2T(stats.worked)}</p>
                </Card>
                <Card className="border border-white/5" style={{ borderColor: stats.balance >= 0 ? 'rgba(34, 197, 94, 0.4)' : 'rgba(239, 68, 68, 0.4)', borderWidth: '1px', borderStyle: 'solid' }}>
                    <p className="text-[10px] font-bold opacity-50 uppercase mb-1">Saldo</p>
                    <p className="text-2xl font-medium">{M2T(stats.balance)}</p>
                </Card>
            </div>

            {/* Quick Action */}
            <div className="flex justify-center py-4">
                <Fab onClick={handleQuickStamp} className="px-12 py-5 gap-3">
                    <Fingerprint className="w-6 h-6" />
                    <span className="text-lg font-medium">Registrar</span>
                </Fab>
            </div>

            {/* Timeline */}
            <div className="space-y-2">
                {record.entries?.sort((a, b) => T2M(a.time) - T2M(b.time)).map(entry => (
                    <Card key={entry.id} className="p-4 flex items-center justify-between">
                        <div className="flex items-center gap-4">
                            {entry.photo ? (
                                <img src={entry.photo} className="w-12 h-12 rounded-xl object-cover border border-white/10" alt="Proof" onClick={() => {/* Zoom logic if needed */ }} />
                            ) : (
                                <label className="w-12 h-12 rounded-xl bg-white/10 flex items-center justify-center text-slate-400 border-2 border-dashed border-white/20 cursor-pointer overflow-hidden hover:bg-white/20 transition-colors">
                                    <Camera size={20} />
                                    <input type="file" accept="image/*" className="hidden" capture="environment" onChange={(e) => handlePhoto(e, entry.id)} />
                                </label>
                            )}
                            <div>
                                <input
                                    type="time"
                                    value={entry.time}
                                    onChange={(e) => updateEntry(entry.id, 'time', e.target.value)}
                                    className="text-xl font-bold bg-transparent border-none p-0 focus:ring-0 w-24 color-inherit outline-none"
                                />
                                <p className="text-[10px] font-bold opacity-40 uppercase tracking-widest">{entry.type}</p>
                            </div>
                        </div>
                        <button onClick={() => confirmDelete(entry.id)} className="text-red-500 opacity-60 hover:opacity-100 p-2"><Trash2 size={20} /></button>
                    </Card>
                ))}
                {record.entries?.length === 0 && <p className="text-center opacity-30 text-sm py-4">Nenhum registro hoje.</p>}
            </div>

            {/* Note */}
            <Card className="p-4">
                <textarea
                    value={record.note || ''}
                    onChange={(e) => updateNote(e.target.value)}
                    className="w-full bg-transparent border-none focus:ring-0 text-sm italic outline-none resize-none"
                    placeholder="Adicionar observação..."
                    rows={2}
                ></textarea>
            </Card>

            <Modal isOpen={isDeleteModalOpen} onClose={() => setDeleteModalOpen(false)} title="Excluir registro?">
                <p className="opacity-70 mb-6">Esta ação não pode ser desfeita.</p>
                <div className="flex justify-end gap-4">
                    <button onClick={() => setDeleteModalOpen(false)} className="px-4 py-2 font-medium opacity-50">Cancelar</button>
                    <button onClick={executeDelete} className="px-6 py-2 bg-red-500 text-white rounded-full font-medium">Excluir</button>
                </div>
            </Modal>
        </div>
    );
};
